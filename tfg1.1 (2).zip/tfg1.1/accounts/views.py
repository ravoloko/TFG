from django.shortcuts import render, redirect
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from presupuesto.models import Presupuesto
from .forms import CustomUserCreationForm # <--- Importamos el nuevo

@login_required
def dashboard(request):
    mis_presupuestos = Presupuesto.objects.filter(usuario=request.user)
    context = {'presupuestos': mis_presupuestos}
    return render(request, 'dashboard.html', context)

def register(request):
    if request.method == 'POST':
        form = CustomUserCreationForm(request.POST) # <--- Usamos el nuevo
        if form.is_valid():
            form.save()
            username = form.cleaned_data.get('username')
            messages.success(request, f'Cuenta creada para {username}.')
            return redirect('login')
    else:
        form = CustomUserCreationForm() # <--- Usamos el nuevo
    
    return render(request, 'registration/signup.html', {'form': form})