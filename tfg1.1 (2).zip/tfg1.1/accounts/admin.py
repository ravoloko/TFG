from django.contrib import admin
from django.contrib.auth.admin import UserAdmin
from .models import User

# Esto hace que el nuevo modelo User aparezca en el panel de control
admin.site.register(User, UserAdmin)