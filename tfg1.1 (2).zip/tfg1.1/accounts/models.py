from django.contrib.auth.models import AbstractUser
from django.db import models

class User(AbstractUser):  # <--- Mira que la "U" sea mayúscula
    ADMIN = 'ADMIN'
    USUARIO = 'USUARIO'
    
    ROLE_CHOICES = [
        (ADMIN, 'Administrador del Sistema'),
        (USUARIO, 'Usuario de Finanzas'),
    ]
    
    rol = models.CharField(
        max_length=20, 
        choices=ROLE_CHOICES, 
        default=USUARIO
    )

    def __str__(self):
        return f"{self.username} ({self.get_rol_display()})"