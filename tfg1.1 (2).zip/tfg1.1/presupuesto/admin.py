from django.contrib import admin
from .models import Presupuesto, LineaPresupuesto, Categoria

# 1. Esto permite añadir líneas de gastos/ingresos directamente dentro del presupuesto
class LineaPresupuestoInline(admin.TabularInline):
    model = LineaPresupuesto
    extra = 1 # Te deja una fila vacía lista para escribir
    fields = ['concepto', 'monto', 'tipo', 'categoria']

@admin.register(Presupuesto)
class PresupuestoAdmin(admin.ModelAdmin):
    # Lo que se ve en la lista principal
    list_display = ('nombre', 'usuario', 'total_calculado_display')
    # Permite meter gastos/ingresos desde la misma pantalla del presupuesto
    inlines = [LineaPresupuestoInline]

    # --- SEGURIDAD DE ARQUITECTURA ---
    
    # A) Solo muestra los presupuestos que pertenecen al usuario que ha hecho login
    def get_queryset(self, request):
        qs = super().get_queryset(request)
        if request.user.is_superuser:
            return qs  # El admin supremo ve todo
        return qs.filter(usuario=request.user)

    # B) Al crear un presupuesto, se asigna automáticamente al usuario logueado
    def save_model(self, request, obj, form, change):
        if not obj.pk: # Si es nuevo
            obj.usuario = request.user
        super().save_model(request, obj, form, change)

    # C) Estética: Añadir el símbolo de € en el panel
    def total_calculado_display(self, obj):
        return f"{obj.total_calculado} €"
    total_calculado_display.short_description = 'Balance Total'

# Registramos la categoría de forma simple
admin.site.register(Categoria)