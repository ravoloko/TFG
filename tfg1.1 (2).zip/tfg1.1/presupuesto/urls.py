from django.urls import path
from . import views

urlpatterns = [
    # 1. La página principal (el diseño oscuro que hicimos)
    path('', views.inicio, name='dashboard'),
    
    # 2. Detalles del presupuesto
    path('presupuesto/<int:pk>/', views.detalle_presupuesto, name='detalle_presupuesto'),
    
    # 3. Gestión de líneas (Editar y Eliminar)
    path('linea/eliminar/<int:pk>/', views.eliminar_linea, name='eliminar_linea'),
    path('linea/editar/<int:pk>/', views.editar_linea, name='editar_linea'),
]