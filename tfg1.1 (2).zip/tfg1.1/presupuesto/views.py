from django.shortcuts import render, get_object_or_404, redirect
from django.contrib.auth.decorators import login_required
from .models import Presupuesto, LineaPresupuesto
from .forms import LineaPresupuestoForm

@login_required
def inicio(request):
    # Traemos los presupuestos del usuario logueado
    presupuestos = Presupuesto.objects.filter(usuario=request.user)
    
    context = {
        'presupuestos': presupuestos,
    }
    # He quitado 'presupuesto/' de la ruta para que busque directamente en tu carpeta 'plantillas'
    return render(request, 'inicio.html', context)

@login_required
def detalle_presupuesto(request, pk):
    # Obtenemos el presupuesto o soltamos un 404 si no existe
    presupuesto = get_object_or_404(Presupuesto, pk=pk, usuario=request.user)
    lineas = presupuesto.lineas.all() 

    if request.method == 'POST':
        form = LineaPresupuestoForm(request.POST)
        if form.is_valid():
            nueva_linea = form.save(commit=False)
            nueva_linea.presupuesto = presupuesto
            nueva_linea.save()
            return redirect('detalle_presupuesto', pk=presupuesto.pk)
    else:
        form = LineaPresupuestoForm()

    context = {
        'presupuesto': presupuesto,
        'lineas': lineas,
        'form': form,
    }
    return render(request, 'detalle.html', context)

@login_required
def eliminar_linea(request, pk):
    linea = get_object_or_404(LineaPresupuesto, pk=pk)
    id_presu = linea.presupuesto.pk
    linea.delete()
    return redirect('detalle_presupuesto', pk=id_presu)

@login_required
def editar_linea(request, pk):
    linea = get_object_or_404(LineaPresupuesto, pk=pk)
    if request.method == 'POST':
        form = LineaPresupuestoForm(request.POST, instance=linea)
        if form.is_valid():
            form.save()
            return redirect('detalle_presupuesto', pk=linea.presupuesto.pk)
    else:
        form = LineaPresupuestoForm(instance=linea)
    return render(request, 'editar_linea.html', {'form': form, 'linea': linea})