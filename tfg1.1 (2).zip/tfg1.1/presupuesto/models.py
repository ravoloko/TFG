from django.db import models
from django.conf import settings  # Esto permite traer el usuario que configuramos

# Nueva tabla para clasificar los gastos/ingresos
class Categoria(models.Model):
    nombre = models.CharField(max_length=50)
    icono = models.CharField(max_length=30, blank=True, null=True)

    def __str__(self):
        return self.nombre

class Presupuesto(models.Model):
    # AQUÍ ESTÁ EL CAMBIO: Usamos settings.AUTH_USER_MODEL en lugar de User
    usuario = models.ForeignKey(
        settings.AUTH_USER_MODEL, 
        on_delete=models.CASCADE
    )
    nombre = models.CharField(max_length=100)
    total_calculated = models.DecimalField(max_digits=12, decimal_places=2, default=0)

    def __str__(self):
        return self.nombre

class LineaPresupuesto(models.Model):
    TIPO_CHOICES = [
        ('INGRESO', 'Ingreso (+)'),
        ('GASTO', 'Gasto (-)'),
    ]

    presupuesto = models.ForeignKey(Presupuesto, on_delete=models.CASCADE, related_name='lineas')
    categoria = models.ForeignKey(Categoria, on_delete=models.SET_NULL, null=True, blank=True)
    concepto = models.CharField(max_length=200)
    monto = models.DecimalField(max_digits=10, decimal_places=2)
    tipo = models.CharField(max_length=10, choices=TIPO_CHOICES, default='GASTO')
    fecha = models.DateField(auto_now_add=True)

    def __str__(self):
        return f"{self.tipo}: {self.concepto} ({self.monto}€)"