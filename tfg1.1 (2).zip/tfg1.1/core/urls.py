from django.contrib import admin
from django.urls import path, include
from presupuesto.views import inicio  # El diseño oscuro
from accounts.views import register   # Tu función de registro

urlpatterns = [
    # 1. Panel de Administración
    path('admin/', admin.site.urls),

    # 2. La Página Principal (Nuestro diseño oscuro)
    # Ahora, al entrar en 127.0.0.1:8000 verás directamente el Dashboard pro
    path('', inicio, name='dashboard'),
    path('dashboard/', inicio),

    # 3. Autenticación (Login, Logout)
    # Esto busca automáticamente los templates en 'registration/login.html'
    path('accounts/', include('django.contrib.auth.urls')),

    # 4. Registro de nuevos usuarios
    path('accounts/signup/', register, name='signup'),

    # 5. Rutas de la App Presupuesto (Detalles, borrar, editar)
    path('presupuesto/', include('presupuesto.urls')),
]